import logo from './logo.svg';
import './App.css';
import Question2 from './components/Question2';

function App() {
  return (
    <>
    <Question2></Question2>
    </>
  );
}

export default App;
