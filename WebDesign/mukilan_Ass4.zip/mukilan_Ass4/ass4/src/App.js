import Application from "./components/Application";

function App() {
  return (
    <Application></Application>
  );
}

export default App;
